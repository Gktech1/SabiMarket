﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using SabiMarket.Domain.Entities.LocalGovernmentAndMArket;
using SabiMarket.Domain.Entities.OrdersAndFeedback;
using SabiMarket.Domain.Entities.UserManagement;

namespace SabiMarket.Domain.Entities.WaiveMarketModule
{
    [Table("Customers")]
    public class Customer : BaseEntity
    {
        public string UserId { get; set; }
        public string LocalGovernmentId { get; set; }
        [Required]
        [StringLength(100)]
        public string FullName { get; set; }
        public DateTime SubscriptionEndDate { get; set; }
        public bool IsSubscriptionActive { get; set; }
        public virtual ApplicationUser User { get; set; }
        public virtual WaivedProduct WaivedProduct { get; set; }
        // Remove this line as it's redundant with Orders collection
        // public virtual CustomerOrder Order { get; set; }  
        public virtual LocalGovernment LocalGovernment { get; set; }
        public virtual ICollection<CustomerOrder> Orders { get; set; }
        public virtual ICollection<CustomerFeedback> Feedbacks { get; set; }
    }
}
